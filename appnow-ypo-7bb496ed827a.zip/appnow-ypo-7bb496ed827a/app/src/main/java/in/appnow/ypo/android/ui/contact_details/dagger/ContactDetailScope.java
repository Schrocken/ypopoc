package in.appnow.ypo.android.ui.contact_details.dagger;

import javax.inject.Scope;

/**
 * Created by Abhishek Thanvi on 15/11/18.
 * Copyright © 2018 CollinsHarper. All rights reserved.
 */

@Scope
public @interface ContactDetailScope {
}
