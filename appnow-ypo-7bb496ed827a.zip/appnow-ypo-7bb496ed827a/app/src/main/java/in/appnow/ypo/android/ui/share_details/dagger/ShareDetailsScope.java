package in.appnow.ypo.android.ui.share_details.dagger;

import javax.inject.Scope;

/**
 * Created by sonu on 18:40, 23/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
@Scope
public @interface ShareDetailsScope {
}
