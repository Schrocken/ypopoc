package in.appnow.ypo.android.interfaces;

/**
 * Created by sonu on 24/12/17.
 */

public interface OnToolbarListener {

    public void updateToolbarTitle(String title);

    public void showHideToolbarElevation(boolean hideElevation);
}
