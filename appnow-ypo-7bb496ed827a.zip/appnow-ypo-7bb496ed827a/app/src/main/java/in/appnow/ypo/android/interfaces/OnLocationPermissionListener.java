package in.appnow.ypo.android.interfaces;

/**
 * Created by Sonu on 17/08/17.
 */

public interface OnLocationPermissionListener {
    public void onLocationPermissionGranted();
    public void onLocationPermissionDenied();
}
