package in.appnow.ypo.android.helper;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * Created by sonu on 27/10/17.
 */

@GlideModule
public class MyAppGlideModule extends AppGlideModule {
}
