package in.appnow.ypo.android.ui.date_time.dagger;

import javax.inject.Scope;

/**
 * Created by sonu on 13:32, 24/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
@Scope
public @interface DateTimeScope {
}
