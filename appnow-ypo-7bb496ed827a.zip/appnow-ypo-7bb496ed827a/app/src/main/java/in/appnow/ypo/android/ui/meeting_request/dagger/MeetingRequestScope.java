package in.appnow.ypo.android.ui.meeting_request.dagger;

import javax.inject.Scope;

/**
 * Created by sonu on 13:06, 24/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
@Scope
public @interface MeetingRequestScope {
}
