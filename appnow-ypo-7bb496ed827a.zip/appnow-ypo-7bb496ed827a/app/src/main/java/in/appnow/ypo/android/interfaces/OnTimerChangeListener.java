package in.appnow.ypo.android.interfaces;

/**
 * Created by sonu on 24/12/17.
 */

public interface OnTimerChangeListener {
    public void updateTimerProgress(int timeCounter);
    public void stopTimer();
}
