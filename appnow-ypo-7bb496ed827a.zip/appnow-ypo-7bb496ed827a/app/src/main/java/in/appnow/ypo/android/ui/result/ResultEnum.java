package in.appnow.ypo.android.ui.result;

/**
 * Created by sonu on 18:10, 23/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
public enum ResultEnum {
    DENY_MEETING_REQUEST,ACCEPT_MEETING_REQUEST, DENY_CONTACT_REQUEST,ACCEPT_CONTACT_REQUEST,NEW_CONTACT,NEW_MEETING;
}
