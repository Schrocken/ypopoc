package in.appnow.ypo.android.interfaces;

import android.support.v4.app.Fragment;

/**
 * Created by Sonu on 14/08/17.
 */

public interface OnFragmentReplaceListener {
    public void replaceFragment(Fragment fragment, String tag);
}
