package in.appnow.ypo.android.interfaces;

/**
 * Created by sonu on 30/01/18.
 */

public interface OnCouponAppliedListener {
    public void onCouponAppliedSuccessfully(String discountAmount);
}
