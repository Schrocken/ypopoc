package in.appnow.ypo.android.interfaces;

/**
 * Created by sonu on 20/01/18.
 */

public interface OnBackPressListener {

    public boolean onBackPress();
}
