package in.appnow.ypo.android.ui.result.dagger;

import javax.inject.Scope;

/**
 * Created by sonu on 17:24, 23/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
@Scope
public @interface ResultScope {
}
