package in.appnow.ypo.android.ui.add_new_contact.dagger;

import javax.inject.Scope;

/**
 * Created by sonu on 16:24, 23/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
@Scope
public @interface AddNewContactScope {
}
