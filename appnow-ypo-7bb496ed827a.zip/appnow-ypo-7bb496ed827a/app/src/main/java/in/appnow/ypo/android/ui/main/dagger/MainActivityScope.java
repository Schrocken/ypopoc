package in.appnow.ypo.android.ui.main.dagger;

import javax.inject.Scope;

/**
 * Created by sonu on 18:11, 18/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
@Scope
public @interface MainActivityScope {
}
