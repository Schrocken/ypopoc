package in.appnow.ypo.android.ui.create_new_bottom_sheet;

/**
 * Created by sonu on 13:25, 23/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
public class CreateNewModel {
    private int icon;
    private String title;

    public int getIcon() {
        return icon;
    }

    public void setIcon(int icon) {
        this.icon = icon;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
