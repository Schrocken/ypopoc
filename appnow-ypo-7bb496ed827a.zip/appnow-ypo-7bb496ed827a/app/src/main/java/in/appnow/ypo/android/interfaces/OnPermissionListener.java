package in.appnow.ypo.android.interfaces;

/**
 * Created by Sonu on 17/08/17.
 */

public interface OnPermissionListener {

    public void onPermissionGranted();

    public void onPermissionDenied();
}
