package in.appnow.ypo.android.dagger.scope;


import javax.inject.Scope;

@Scope
public @interface AppScope {
}
