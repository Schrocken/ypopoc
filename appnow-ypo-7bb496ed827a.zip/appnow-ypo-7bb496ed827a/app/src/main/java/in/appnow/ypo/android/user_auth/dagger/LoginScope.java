package in.appnow.ypo.android.user_auth.dagger;

import javax.inject.Scope;

/**
 * Created by sonu on 18:37, 18/10/18
 * Copyright (c) 2018 . All rights reserved.
 */
@Scope
public @interface LoginScope {
}
